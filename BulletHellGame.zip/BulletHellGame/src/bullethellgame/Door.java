package bullethellgame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import bullethellgame.Game.STATE;

public class Door extends GameObject{

	private boolean open;
	private Game game;
	private Room room;


	public Door(int x, int y, ID id, int length, int width, Handler handler, Game game, Room room, boolean open) {
		super(x, y, id, length, width, handler);
		this.game = game;
		this.room = room;
		this.open = open;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tick() {
		// TODO Auto-generated method stub
			collision();
	}

	@Override
	public void render(Graphics g) {
		if (this.isOpen()) g.setColor(Color.GREEN);
		else g.setColor(Color.RED);
		g.fillRect(this.x, this.y, 32, 32);
//		g.drawString(Integer.toString(this.x), 50, 50);
//		g.drawString(Integer.toString(this.y), 100, 50);
	}
	
	private void collision() {
		for (int i = 0; i < handler.objectList.size(); i++) {
			GameObject tempObject = handler.objectList.get(i);
			
			if (tempObject.getID() == ID.Player)
				if(getBounds().intersects(tempObject.getBounds())) {
//					collision code
					if (this.isOpen()) {

						if (this.room == null ) {
							HUD.HEALTH = 100;
							handler.clearEnemies();
							game.gameState = STATE.WinScreen;
	//						game.gameState = Game.STATE.GameOver;
						} else {
						game.current_room = this.room;
						game.current_room.setEntered_room(true);
						handler.removeObject(this);
						tempObject.setX(Game.WIDTH/2-32);
						tempObject.setY(Game.HEIGHT/2-32);
						}
						
					}
					else {
						block();
					}
				}
			}
		}

	@Override
	public Rectangle getBounds() {
		// TODO Auto-generated method stub
		return new Rectangle(x, y, 32, 32);
	}

	public boolean isOpen() {
		return open;
	}

	public void setOpen(boolean open) {
		this.open = open;
	}

}
