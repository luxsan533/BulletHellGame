/**
 * 
 */
/**
 * @author Luxsan Jeyasingam
 *
 */
module BulletHellGame {
	requires java.desktop;
	requires jdk.unsupported;
}